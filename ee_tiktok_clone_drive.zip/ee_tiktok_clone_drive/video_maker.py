import os, io, math, random, requests, tempfile
from moviepy.editor import VideoFileClip, CompositeVideoClip, ImageClip
from PIL import Image, ImageDraw, ImageFont

PEXELS_API_KEY = os.getenv("PEXELS_API_KEY","")

def _pick_font(size):
    try:
        return ImageFont.truetype("DejaVuSans-Bold.ttf", size=size)
    except Exception:
        return ImageFont.load_default()

def _render_text_image(text, size, font_size=56, padding=40, box_alpha=160):
    W, H = size
    img = Image.new("RGBA", (W, H), (0,0,0,0))
    draw = ImageDraw.Draw(img)
    font = _pick_font(font_size)
    # wrap rough
    max_width = int(W*0.85)
    def wrap(par):
        words = par.split()
        cur, lines = "", []
        for w in words:
            test = (cur + " " + w).strip()
            tw, th = draw.textbbox((0,0), test, font=font)[2:4]
            if tw <= max_width: cur = test
            else: lines.append(cur); cur = w
        if cur: lines.append(cur)
        return lines
    lines = []
    for par in text.split("\n"):
        if par.strip(): lines += wrap(par)
        else: lines.append("")
    line_h = int(font_size * 1.3)
    block_h = line_h * (len(lines) + 2)
    block_w = max([draw.textbbox((0,0), ln, font=font)[2] if ln else 0 for ln in lines] + [0]) + padding*2
    block_w = min(block_w, int(W*0.92))
    box_x = (W - block_w)//2
    box_y = H - int(H*0.3) - block_h//2
    box = Image.new("RGBA", (block_w, block_h), (0,0,0,box_alpha))
    img.alpha_composite(box, (box_x, box_y))
    y = box_y + padding//2
    for ln in lines:
        tw = draw.textbbox((0,0), ln, font=font)[2] if ln else 0
        x = (W - tw)//2
        draw.text((x, y), ln, font=font, fill=(255,255,255,255))
        y += line_h
    return img

def fetch_pexels_clip(query):
    if not PEXELS_API_KEY:
        raise RuntimeError("PEXELS_API_KEY missing.")
    url = f"https://api.pexels.com/videos/search?query={query}&per_page=1&orientation=portrait"
    r = requests.get(url, headers={"Authorization": PEXELS_API_KEY}, timeout=60)
    r.raise_for_status()
    data = r.json()
    if not data.get("videos"):
        raise RuntimeError("No videos from Pexels for query: " + query)
    files = data["videos"][0]["video_files"]
    files_sorted = sorted(files, key=lambda f: (abs((f.get("width") or 1080) - 1080), f.get("height") or 1920))
    video_url = files_sorted[0]["link"]
    vid = requests.get(video_url, timeout=120).content
    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
    tmp.write(vid); tmp.close()
    return tmp.name

def make_video(onscreen_lines, queries, out_path, duration_sec=16):
    query = random.choice(queries)
    src = fetch_pexels_clip(query)
    bg = VideoFileClip(src)
    target_w, target_h = 1080, 1920
    bg = bg.resize(height=target_h)
    if bg.w != target_w:
        x1 = (bg.w - target_w) // 2
        bg = bg.crop(x1=x1, width=target_w, height=target_h)
    if bg.duration > duration_sec:
        bg = bg.subclip(0, duration_sec)
    else:
        loops = math.ceil(duration_sec / bg.duration)
        from moviepy.editor import concatenate_videoclips
        bg = concatenate_videoclips([bg]*loops).subclip(0, duration_sec)
    overlays = []
    if len(onscreen_lines) >= 3:
        chunks = [onscreen_lines[0:1], onscreen_lines[1:-1], onscreen_lines[-1:]]
    else:
        chunks = [onscreen_lines]
    seg = duration_sec / len(chunks)
    for chunk in chunks:
        text = "\n".join(chunk)
        img = _render_text_image(text, (target_w, target_h), font_size=56)
        iclip = ImageClip(img).set_duration(seg).set_position(("center","center"))
        overlays.append(iclip)
    final = CompositeVideoClip([bg] + overlays)
    final.write_videofile(out_path, fps=30, codec="libx264", audio=False, verbose=False, logger=None)
    return out_path
