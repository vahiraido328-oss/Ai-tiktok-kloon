import random

EST_HOOKS = [
    "3 nippi, mis kiirendavad sinu sisu loomist ⏱️",
    "Kuidas teha TikToki ilma nägu näitamata?",
    "Lihtne süsteem: 15 min päevas → 1 video",
    "AI tööriistad, mis säästavad sul aega",
    "Algajale: kuidas alustada digikõrvaltööga"
]

EST_CTAS = [
    "Talleta ja jaga sõbrale 👇",
    "Jälgi veel lihtsate AI-nippide jaoks 🤖",
    "Kirjuta kommentaaridesse, kumb nipp aitas!",
    "Proovi täna ühte sammu ja tagasta siia tulemused.",
    "Jälgi — iga päev 1 lihtne video."
]

EST_POINTS = [
    ["Vali 1 teema, mitte 5.","Kasuta sama vormingut iga päev.","Automatiseeri pealkirjad."],
    ["Võta stock-video taustaks.","Pane tekst ekraanile.","Lisa tugev CTA lõppu."],
    ["Kirjuta numbritega.","Testi 3 hook'i.","Hoia 7–15 sekundi klipid."],
    ["Kasuta CapCut/Canva malle.","Kirjuta enne video tegemist tekst valmis.","Loo 3 klippi korraga."],
    ["Tee ideede nimekiri Notionis.","Taaskasuta parimaid klippe.","Ära jahmerda filtritega, fookus on sisul."]
]

def gen_post(topics, hashtags):
    hook = random.choice(EST_HOOKS)
    points = random.choice(EST_POINTS)
    cta = random.choice(EST_CTAS)
    h = " ".join(random.sample(hashtags, min(4, len(hashtags))))
    lines = [hook, ""] + [f"- {p}" for p in points] + ["", cta, h]
    caption = "\n".join(lines)
    onscreen = [hook] + points + [cta]
    return {"caption": caption, "onscreen_lines": onscreen}
