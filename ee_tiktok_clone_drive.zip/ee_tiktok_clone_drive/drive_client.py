import os, json, mimetypes
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = ["https://www.googleapis.com/auth/drive.file"]

def _service():
    creds_json = os.getenv("GOOGLE_CREDENTIALS","")
    if not creds_json:
        raise RuntimeError("GOOGLE_CREDENTIALS missing.")
    info = json.loads(creds_json)
    creds = service_account.Credentials.from_service_account_info(info, scopes=SCOPES)
    return build("drive", "v3", credentials=creds, cache_discovery=False)

def upload_file(local_path, folder_id):
    service = _service()
    fname = os.path.basename(local_path)
    mime, _ = mimetypes.guess_type(local_path)
    media = MediaFileUpload(local_path, mimetype=mime or "application/octet-stream", resumable=True)
    body = {"name": fname, "parents": [folder_id]} if folder_id else {"name": fname}
    return service.files().create(body=body, media_body=media, fields="id,name,webViewLink").execute()
