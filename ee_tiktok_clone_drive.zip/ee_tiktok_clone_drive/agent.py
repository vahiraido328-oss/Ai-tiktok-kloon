import os, json
from datetime import datetime
from providers.llm_provider import gen_post
from video_maker import make_video
from drive_client import upload_file

def load_config():
    with open("config.json","r",encoding="utf-8") as f:
        return json.load(f)

def main():
    cfg = load_config()
    n = cfg["schedule"]["posts_per_day"]
    folder_id = cfg["drive"]["folder_id"]
    queries = cfg["video"]["pexels_queries"]
    dur = cfg["video"]["duration_sec"]
    topics = cfg["topics"]
    hashtags = cfg["hashtags"]
    results = []
    for i in range(n):
        post = gen_post(topics, hashtags)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        vpath = f"tiktok_{stamp}_{i+1}.mp4"
        tpath = f"tiktok_{stamp}_{i+1}_caption.txt"
        make_video(post["onscreen_lines"], queries, vpath, duration_sec=dur)
        with open(tpath,"w",encoding="utf-8") as f:
            f.write(post["caption"])
        upv = upload_file(vpath, folder_id)
        upt = upload_file(tpath, folder_id)
        results.append({"video": upv, "caption": upt})
    print(json.dumps({"uploaded": len(results), "links": results}, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
